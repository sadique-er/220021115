import cv2
import os
import glob
from os import listdir

for i, images in enumerate(glob.glob("D:/image/*.png"), 1):
    img = cv2.imread(images)
    resized = cv2.resize(img, (224, 224))
    normalized = resized / 255.0

    
    cv2.imwrite(os.path.join("D:/image/new", '{}.jpg'.format(i)), normalized) 
    cv2.waitKey(0)


                   