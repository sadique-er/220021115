from ultralytics import YOLOv10
import os

model=YOLOv10(f'C:/Users/User/Downloads/best.pt')
#model.train(data="D:\Program Files\bird.v1i.yolov8\train\data.yaml", epochs=100, imgsz=224)
model(source="C:/Users/User/Downloads/istockphoto-499898060-612x612.jpg", conf=0.25)